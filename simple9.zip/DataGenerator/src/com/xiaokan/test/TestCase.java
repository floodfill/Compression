package com.xiaokan.test;

import java.io.IOException;
import java.util.Random;

import com.xiaokan.algo.Simple16Codec;

public class TestCase {

	public static void main(String args[]) throws IOException {

		Simple16Codec s = new Simple16Codec();
		int[] org = new int[300];
		Random rand = new Random();
		for (int i = 0; i < org.length; i++) {
			org[i] = rand.nextInt(5000) + 1;
		}
		for (int b : org) {
			System.out.format("%d ", b);
		}
		System.out.println();
		byte com[] = s.encode(org);

		System.out.println("Length: " + com.length);
		int dec[] = s.decode(com);

		for (int b : dec) {
			System.out.format("%d ", b);
		}
		System.out.println();
		for (int i = 0; i < 300; i++) {
			assert dec[i] == org[i];
		}

	}
}
